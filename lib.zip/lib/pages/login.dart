

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class login extends StatefulWidget {
  const login({super.key});

  @override
  State<login> createState() => _loginState();
}

class _loginState extends State<login> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      body:Container(decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/images/loginbg.webp"),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(child: Container(width: 500 ,height: 600,color: Color.fromARGB(239, 40, 48, 52).withOpacity(0.9),)),
        )
    );
  }
}